const Config = {
  PATHNAME: "/rwad/website",
  HREF_START_INDEX: 13,
};
