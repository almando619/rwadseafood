if (window.location.pathname === `${Config.PATHNAME}/home`) {
}
