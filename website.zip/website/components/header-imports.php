<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="icon" type="image/x-icon" href="assets/icons/logo.png">

<!-- Fontawesome 6 icons -->
<link rel="stylesheet" href="assets/css/fa-css/all.css" />
<link rel="stylesheet" href="assets/css/fa-css/all.min.css" />
<link rel="stylesheet" href="assets/css/fa-css/brands.css" />
<link rel="stylesheet" href="assets/css/fa-css/brands.min.css" />
<link rel="stylesheet" href="assets/css/fa-css/regular.css" />
<link rel="stylesheet" href="assets/css/fa-css/regular.min.css" />
<link rel="stylesheet" href="assets/css/fa-css/solid.css" />
<link rel="stylesheet" href="assets/css/fa-css/solid.min.css" />
<link rel="stylesheet" href="assets/css/fa-css/fontawesome.css" />
<link rel="stylesheet" href="assets/css/fa-css/fontawesome.min.css" />
<link rel="stylesheet" href="assets/css/fa-css/svg-with-js.css" />
<link rel="stylesheet" href="assets/css/fa-css/svg-with-js.min.css" />
<link rel="stylesheet" href="assets/css/fa-css/v4-font-face.css" />
<link rel="stylesheet" href="assets/css/fa-css/v4-font-face.min.css" />
<link rel="stylesheet" href="assets/css/fa-css/v4-shims.css" />
<link rel="stylesheet" href="assets/css/fa-css/v4-shims.min.css" />
<link rel="stylesheet" href="assets/css/fa-css/v5-font-face.css" />
<link rel="stylesheet" href="assets/css/fa-css/v5-font-face.min.css" />
<!-- Fontawesome 6 icons -->

<!-- Swiper Js css -->
<link rel="stylesheet" href="assets/js/swiper/swiper-bundle.min.css" />
<!-- Swiper Js- css -->

<!-- pages and components css -->
<link rel="stylesheet" type="text/css" href="assets/css/app.css" />
<link rel="stylesheet" type="text/css" href="assets/css/top-bar.css" />
<link rel="stylesheet" type="text/css" href="assets/css/footer.css" />
<link rel="stylesheet" type="text/css" href="assets/css/home.css" />
<link rel="stylesheet" type="text/css" href="assets/css/about.css" />
<link rel="stylesheet" type="text/css" href="assets/css/products.css" />
<link rel="stylesheet" type="text/css" href="assets/css/contacts.css" />
<!-- pages and components css -->