<?php
$DB_USER = "root";
$DB_PASSWORD = "";
$DB_HOST = "localhost";
$DB_NAME = "jemcapital";

// $DB_USER = "jemcapital_jem";
// $DB_PASSWORD = "jem@databasePass123";
// $DB_HOST = "localhost";
// $DB_NAME = "jemcapital_jem";

$conn = mysqli_connect($DB_HOST, $DB_USER, $DB_PASSWORD, $DB_NAME);
